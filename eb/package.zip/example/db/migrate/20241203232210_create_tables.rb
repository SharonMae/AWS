class CreateTables < ActiveRecord::Migration[8.0]
  def change
    unless table_exists?(:things)
      create_table :things do |t|
        t.string :name
        t.timestamps
      end

      # Move data seeding logic to seeds.rb
    end
  end
end

