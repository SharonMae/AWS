Thing.create!(name: "Hello")
Thing.create!(name: "World")
Thing.create!(name: "Goodbye")
Thing.create!(name: "Moon")

